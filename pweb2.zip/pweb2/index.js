const express = require('express');
const server = express();

server.get('/crud, ( req, res) =>  
    return res.json( { message: "Hello world" })
);
    server.listen(3000);


server.get('crud', (req, res) => {
    return res.json(web2);
    })
















